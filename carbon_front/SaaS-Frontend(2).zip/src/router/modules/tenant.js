// import Layout from '@/layout'
// let tenantRouter = {
//   path: '/sysTenant/',
//   component: Layout,
//   name: 'User',
//   // meta: {
//   //   title: '租户',
//   //   icon: 'tenant'
//   // },
//   children: [
//     {
//       path: '/',
//       component: () => import('@/views/tenant/index.vue'),
//       name: 'tentant',
//       meta: { title: '租户管理', icon: '' }
//     },
//   ]
// }

// export default tenantRouter;