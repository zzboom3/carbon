import Layout from '@/layout'
let tradeRouter = {
  path: '/trade',
  component: Layout,
  name: 'trade',
  // meta: {
  //   title: '交易',
  //   icon: 'trade'
  // },
  children: []
}

export default tradeRouter;