<template>
    <div style="background: #fff;height: 50px;display:flex;justify-content:space-between">
     <div style="display:flex;align-items:center">
      <img style="margin-left:10px;width: 30px; height: 30px" src="@/assets/imgs/icon_home_logo.png"/>
     </div>
   </div>
</template>

<script>
export default {
  name: 'UserInfo',
  data() {
    return {

    }
  },
  computed: {
    
  },
  created() {
    
  }
}
</script>