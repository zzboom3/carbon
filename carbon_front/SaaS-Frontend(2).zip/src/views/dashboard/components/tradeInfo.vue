<template>
    <div class="root">
        <div>
          <a class="nav-title">碳交易行情</a>
          <a class="nav-subtitle">{{quotation.statDate}}</a>
        </div>
        <div class="card-container">
            <div class="chart-container"> 
              <i class="chart-top-text">CCER签发量:{{quotation.ccerCount}}</i>
              <div id="xunjian_echart" style="margin-left:10px;width:168.18px;height:168.18px"/>
               <i class="chart-unit">单位: tCO2e</i>
               <div class="chart-info-bg">
                   <div class="wrap-div">
                    <div class="info-line">
                    <div class="green-point"/>
                    <i class="hint-text">已核销，{{quotation.writtenOffCount}} ，{{percentWrittenOffCount}}%</i>
                   </div>
                   <div class="info-line">
                    <div class="blue-point"/>
                    <i class="hint-text">存量，{{quotation.stockCount}} ，{{percentStockCount}}%</i>
                   </div>
                </div>
               </div>
            </div>

            <div class="chart-container"> 
               <i class="chart-top-text">CCER项目量: {{quotation.ccerProjectCount}}</i>
               <div id="lvxin_echart" style="margin-left:10px;width:168.18px;height:168.18px"/>
                <i class="chart-unit">单位: 个</i>
               
               <div class="chart-info-bg">
                  <div class="wrap-div">
                  <div class="info-line">
                    <div class="green-point"/>
                    <i class="hint-text">已审定，{{quotation.approvedCount}} 个，{{percentApprovedCount}}%</i>
                   </div>
                   <div class="info-line">
                    <div class="blue-point"/>
                    <i class="hint-text">已备案，{{quotation.filingCount}}  个，{{percentFilingCount}}%</i>
                   </div>
                   <div class="info-line">
                    <div class="lint-blue-point"/>
                    <i class="hint-text">已签发，{{quotation.singCount}}  个，{{percentSingCount}}%</i>
                   </div>
               </div>
               </div>
            </div>

            <el-table
              :header-cell-style="{textAlign: 'center'}"
              :cell-style="{'text-align':'center'}"
              class="table-div"
              :data="quotation.projects"
              stripe
              style="width: 100%">
              <el-table-column
                prop="type"
                label="项目类型"
                width="180">
              </el-table-column>
              <el-table-column
                prop="singCount"
                label="签发量(tCO2e)"
                width="180">
              </el-table-column>
              <el-table-column
                prop="stockCount"
                label="存量(tCO2e)">
              </el-table-column>
              <el-table-column
                prop="singCount"
                label="项目数量(个)">
              </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
  import * as echarts from 'echarts';
  import {getHomePanelData} from '@/api/homeApi.js'
  import { getToken } from '@/utils/auth'
  export default {
    name: 'tradeInfo',
    data() {
      return {
       ccerCount: 4950,
       stockCount:100,  //	存量	integer	
       writtenOffCount: 200,//	已核销
       percentStockCount: 0,
       percentWrittenOffCount: 0,

       ccerProjectCount: 3424,
       singCount: 224,//	已签发
       filingCount: 134,//	已备案
       approvedCount: 133,//	已审定
       percentSingCount: 0,
       percentFilingCount: 0,
       percentApprovedCount: 0,
      }
    },

    props: {
      quotation:{}
    },
    mounted() {
      // this.ccerCount = this.quotation.ccerCount
      this.cacultePercent()
      this.drawRing()
    },

    computed: {
    },

    methods: {
      cacultePercent() {
        let token = getToken()
        getHomePanelData(token).then( res => {
        let quotation = res.quotation
        this.ccerCount = quotation.ccerCount
        this.stockCount = quotation.stockCount
        this.writtenOffCount = quotation.writtenOffCount

        this.ccerProjectCount = quotation.ccerProjectCount
        this.singCount = quotation.singCount
        this.filingCount = quotation.filingCount
        this.approvedCount = quotation.approvedCount

        this.percentStockCount = parseFloat(this.stockCount / this.ccerCount * 100).toFixed(2)
        this.percentWrittenOffCount = parseFloat(this.writtenOffCount / this.ccerCount * 100).toFixed(2)
        this.percentSingCount = parseFloat(this.singCount / this.ccerProjectCount* 100).toFixed(2)
        this.percentFilingCount = parseFloat(this.filingCount / this.ccerProjectCount * 100).toFixed(2)
        this.percentApprovedCount = parseFloat(this.approvedCount / this.ccerProjectCount * 100).toFixed(2)
       }
      ).catch((res) => {
      })
      },
      drawRing() {
         //  初始化统计图表
          var xj = document.getElementById('xunjian_echart');
          var xunjian = echarts.init(xj);

          var lv = document.getElementById('lvxin_echart');
          var lvxin = echarts.init(lv);
          //设置数据
          var option_xunjian = {
              color: ["#26B581", "#0065FF ", "#009EFF", "#4EDBB7"],
              tooltip: {
                trigger: 'item'
              },
              title: {
                show: true,
                text: this.ccerCount, // 当前写死
                left: 80.08,
                top: 66.08,
                textAlign: 'center',
                textStyle: {
                  fontSize: '12',
                  fontWeight: 'bold'
                },
             },
              series: [
                {
                  // name: 'Access From',
                  type: 'pie',
                  radius: ['30%', '80%'],
                  avoidLabelOverlap: false,
                  label: {
                    show: false,
                    position: 'center'
                  },
                  emphasis: {
                    label: {
                      show: true,
                      fontSize: '12',
                      // fontWeight: 'bold'
                    }
                  },
                  labelLine: {
                    show: true
                  },
                  data: [
                    { value: this.stockCount, name: '存量' },
                    { value: this.writtenOffCount, name: '已核销' },
                  ]
                }
              ]
          };
          var option_lvxin = {
              color: ["#26B581", "#0065FF ", "#009EFF", "#4EDBB7"],
              tooltip: {
                trigger: 'item'
              },
              title: {
                show: true,
                text: this.ccerProjectCount, 
                left: 80.08,
                top: 66.08,
                textAlign: 'center',
                textStyle: {
                  fontSize: '12',
                  fontWeight: 'bold'
                },
             },
              series: [
                {
                  type: 'pie',
                  radius: ['30%', '80%'],
                  avoidLabelOverlap: false,
                  label: {
                    show: false,
                    position: 'center'
                  },
                  emphasis: {
                    label: {
                      show: true,
                      fontSize: '12',
                    }
                  },
                  labelLine: {
                    show: true
                  },
                  data: [
                    { value: this.approvedCount, name: '已审定' },
                    { value: this.filingCount, name: '已备案' },
                    { value: this.singCount, name: '已签发' },
                  ]
                }
              ]
          };
   
          //实例化
          xunjian.setOption(option_xunjian);

          lvxin.setOption(option_lvxin);
      }
    },
    created() {
      
    }
  }
</script>
<style lang="scss" scoped>
.root {
    display: flex;
    flex-direction: column;
    margin-top: 20px;
    margin-left: 20px;
    .card-container {
        margin-top: 6px;
        margin-right: 24px;
        display: flex;
        flex-direction: row;
        height: 368px;
        background: #FFFFFF;
        box-shadow: 0px 2px 8px 0px #EAF0F3;
        border-radius: 8px;
    }
}
.nav-title {
    margin-top: 20px;
    font-size: 18px;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    color: #080B0D;
    cursor: default;
}
.nav-subtitle {
  margin-left: 12px;
  font-size: 13px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: #5E6C84;
}
.chart-container {
  display: flex;
  flex-direction: column;
  margin-left: 60px;
  margin-top: 37px;
  margin-bottom: 30px;
  width: 201px;
}
.chart-top-text {
  text-align: center;
  font-size: 17px;
  font-family: Barlow-Medium, Barlow;
  font-weight: 500;
  color: #424C5C;
}
.chart-unit {
  text-align: center;
  font-size: 13px;
  font-family: Barlow-Regular, Barlow;
  font-weight: 400;
  color: #5E6C84;
  // margin-left: 60px;
}
.chart-info-bg {
   display: flex;
   flex-direction: column;
   margin-top: 20px;
   width: 201px;
   height: 111px;
   background-image: url('../../../assets/imgs/bg_chart_info.png');
   background-repeat: no-repeat;
}
.green-point {
  border-radius: 5px;
  width: 10px;
  height: 10px;
  margin-top: 5px;
  // margin-left: 20px;
  margin-right: 10px;
  background: linear-gradient(180deg, #4EDBB7 0%, #26B581 100%);  
}
.blue-point {
  border-radius: 5px;
  width: 10px;
  height: 10px;
  margin-top: 5px;
  // margin-left: 20px;
  margin-right: 10px;
  background: linear-gradient(180deg, #009EFF 0%, #0065FF 100%);
}
.lint-blue-point {
  border-radius: 5px;
  width: 10px;
  height: 10px;
  margin-top: 5px;
  // margin-left: 20px;
  margin-right: 10px;
  background: linear-gradient(180deg, #2FD5E1 0%, #15AABF 100%);
}
.info-line {
  // margin-top: 10px;
  display: flex;
  flex-direction: row;
  line-height: 20px;
}
.hint-text {
  font-size: 13px;
  font-family: Barlow-Regular, Barlow;
  font-weight: 400;
  color: #424C5C;
}
.table-div{
  margin-left: 10px;
  margin-right: 24px;
  margin-top: 30px;
  margin-bottom: 30px;
}
.wrap-div {
  margin: auto;
}
</style>