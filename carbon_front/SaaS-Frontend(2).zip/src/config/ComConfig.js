export const greenUnit ='kWh'
export const creditUnit ='tCO2e'
export const qoutaUnit ='tCO2e'
export const cncUnit = 'CNC'
