export function cellStyle(data) {
if(data.columnIndex===1){
return "cursor:pointer;"
}
}